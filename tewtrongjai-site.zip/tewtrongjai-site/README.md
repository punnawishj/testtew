# ติวตรงใจ — เว็บไซต์ + Airtable

หน้าเว็บ (`index.html`) เหมือนกับดีไซน์ที่ทำไว้ใน Claude ทุกอย่าง แต่เปลี่ยนจากข้อมูลตัวอย่างในหน่วยความจำ
มาเป็นการดึง/บันทึกข้อมูลจริงผ่าน Airtable โดยผ่านตัวกลาง (`/api/tutors`, `/api/postings`) ที่รันบนเซิร์ฟเวอร์
เพื่อไม่ให้ Airtable API key หลุดไปอยู่ในหน้าเว็บที่ใครก็เปิดดูโค้ดได้

## โครงสร้างไฟล์

```
tewtrongjai-site/
  index.html          หน้าเว็บสาธารณะ (ติวเตอร์ + กระดานประกาศ + ฟอร์ม)
  api/tutors.js        GET = ดึงติวเตอร์ที่อนุมัติแล้ว, POST = รับใบสมัครติวเตอร์ใหม่ (สถานะ Pending)
  api/postings.js       GET = ดึงประกาศทั้งหมด, POST = รับประกาศใหม่ (แสดงทันที ไม่ต้องอนุมัติ)
  .env.example          ตัวอย่างตัวแปรที่ต้องตั้งค่า (ห้ามใส่ค่าจริงในไฟล์นี้)
```

## ขั้นตอนที่ 1 — สร้าง Airtable base

สร้าง base ใหม่ชื่ออะไรก็ได้ (เช่น "ติวตรงใจ") แล้วสร้าง 2 ตารางตามนี้ **ชื่อฟิลด์ต้องตรงเป๊ะ** (ตัวพิมพ์เล็ก-ใหญ่มีผล):

**ตาราง `Tutors`**
| ฟิลด์ | ประเภท |
|---|---|
| Name | Single line text |
| Phone | Single line text |
| Subject | Single line text |
| Rate | Number |
| Education | Single line text |
| Bio | Long text |
| Status | Single select — ตัวเลือก: `Pending`, `Approved`, `Rejected` |
| CreatedAt | Created time |

**ตาราง `Postings`**
| ฟิลด์ | ประเภท |
|---|---|
| Subject | Single line text |
| Level | Single line text |
| Budget | Single line text |
| Format | Single line text |
| Detail | Long text |
| CreatedAt | Created time |

## ขั้นตอนที่ 2 — สร้าง Personal Access Token

1. ไปที่ https://airtable.com/create/tokens
2. สร้าง token ใหม่ ตั้ง scope เป็น `data.records:read` และ `data.records:write`
3. จำกัด access ให้เฉพาะ base ที่สร้างไว้ในขั้นตอนที่ 1 เท่านั้น (อย่าให้ token เข้าถึง base อื่น)
4. คัดลอก token เก็บไว้ (ขึ้นต้นด้วย `pat...`) — จะได้ใช้ในขั้นตอนที่ 4

หา **Base ID** ได้จากหน้า https://airtable.com/api แล้วเลือก base ของคุณ (ขึ้นต้นด้วย `app...`)

## ขั้นตอนที่ 3 — เตรียมโปรเจกต์

โฟลเดอร์นี้พร้อม deploy อยู่แล้ว ไม่ต้องสั่ง `npm install` เพราะฟังก์ชันใช้ `fetch` ที่มีอยู่ในตัว Node.js
runtime ของ Vercel อยู่แล้ว (ไม่พึ่ง library ภายนอก)

แนะนำให้ push โฟลเดอร์นี้ขึ้น GitHub repo ใหม่ (private ก็ได้) เพราะ Vercel deploy ผ่านการเชื่อม GitHub
ได้ง่ายและอัปเดตอัตโนมัติทุกครั้งที่ push โค้ดใหม่

## ขั้นตอนที่ 4 — Deploy บน Vercel

1. ไปที่ https://vercel.com แล้ว "Add New Project" เลือก repo ที่ push ไว้
2. ตอนตั้งค่าโปรเจกต์ ไม่ต้องแก้ Build settings อะไร (เป็น static + serverless function อยู่แล้ว)
3. ไปที่ Project Settings > Environment Variables เพิ่ม:
   - `AIRTABLE_PAT` = token จากขั้นตอนที่ 2
   - `AIRTABLE_BASE_ID` = base ID จากขั้นตอนที่ 2
4. กด Deploy — จะได้ URL เช่น `tewtrongjai.vercel.app`
5. (ถ้ามีโดเมนของตัวเอง) ไปที่ Project Settings > Domains เพื่อผูกโดเมน

> ใช้ Netlify แทนก็ได้ ขั้นตอนใกล้เคียงกันมาก แค่ไฟล์ในโฟลเดอร์ `api/` จะต้องปรับ syntax
> เป็นรูปแบบของ Netlify Functions เล็กน้อย (โครงสร้าง request/response ต่างจาก Vercel นิดหน่อย)

## ขั้นตอนที่ 5 — อนุมัติติวเตอร์

ไม่ต้องสร้างหน้า admin แยกต่างหาก — เปิด Airtable (เว็บหรือแอปมือถือ) แล้วดูตาราง `Tutors`
ที่มี Status = `Pending` ตรวจสอบข้อมูล แล้วเปลี่ยน Status เป็น `Approved` เมื่อพอใจ
ติวเตอร์คนนั้นจะขึ้นแสดงในหน้าเว็บทันทีที่มีคนรีเฟรชหน้า (ระบบดึงข้อมูลใหม่ทุกครั้งที่โหลดหน้า
ไม่ใช่แบบเรียลไทม์ ซึ่งเพียงพอสำหรับการใช้งานช่วงแรก)

ถ้าอยากให้สะดวกขึ้น ตั้งค่า Airtable Automation ส่งแจ้งเตือนเข้า Line/อีเมลทุกครั้งที่มีแถวใหม่ใน
`Tutors` ที่ Status = Pending ก็ทำได้จากเมนู Automations ในตัว Airtable เอง

## หมายเหตุด้านความปลอดภัย

- Airtable PAT อยู่เฉพาะฝั่งเซิร์ฟเวอร์ (environment variable) เท่านั้น ไม่เคยถูกส่งไปที่เบราว์เซอร์
- ฟอร์มไม่มีการตรวจสอบตัวตนผู้ส่ง (เหมือนฟอร์มทั่วไป) หากพบการส่งสแปมจำนวนมาก ควรเพิ่ม CAPTCHA
  (เช่น Cloudflare Turnstile ซึ่งใช้ฟรี) ที่หน้าฟอร์มทั้งสอง
- Airtable free plan จำกัดจำนวนแถวต่อ base — ถ้าจำนวนติวเตอร์/ประกาศเพิ่มมาก อาจต้องอัปเกรดแผน
